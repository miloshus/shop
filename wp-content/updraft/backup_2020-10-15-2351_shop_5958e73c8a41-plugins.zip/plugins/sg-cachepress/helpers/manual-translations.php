<?php
__( 'SuperCacher Settings', 'sg-cachepress' );
__( 'Environment Optimization', 'sg-cachepress' );
__( 'Frontend Optimization', 'sg-cachepress' );
__( 'Media Optimization', 'sg-cachepress' );
__( 'Performance Test', 'sg-cachepress' );
